from tkinter import*
from tkinter import ttk
import tkinter
from tkinter import messagebox
from PIL import Image,ImageTk
from student import Student_Details
import os
from time import strftime
from datetime import datetime
from train import Training
from Faceit import Facedetecting 
from attendit import Attend
from Developer import developer
from Helpy import helpi
class Face_Recognize:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1275x910+0+0")
        self.root.title("Facial Recognition System")
#1st
        img=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\facebg.jpg")
        img=img.resize((450,130),Image.ANTIALIAS)
        self.photoimg=ImageTk.PhotoImage(img)

        firstlabel=Label(self.root,image=self.photoimg)
        firstlabel.place(x=0,y=0,width=450,height=130)
#2nd
        img2=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\facebg2.jpg")
        img2=img2.resize((450,130),Image.ANTIALIAS)
        self.photoimg2=ImageTk.PhotoImage(img2)

        seclabel=Label(self.root,image=self.photoimg2)
        seclabel.place(x=450,y=0,width=450,height=130)
#3rd
        img3=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\facebg3.jpg")
        img3=img3.resize((450,130),Image.ANTIALIAS)
        self.photoimg3=ImageTk.PhotoImage(img3)

        thirdlabel=Label(self.root,image=self.photoimg3)
        thirdlabel.place(x=900,y=0,width=450,height=130)

#background
        bgimg=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\facialbg.png")
        bgimg=bgimg.resize((1380,600),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(bgimg)

        bag_img=Label(self.root,image=self.photoimg4)
        bag_img.place(x=0,y=130,width=1380,height=600)

#title
        titlelbl=Label(bag_img,text="FACE RECOGNITION ATTENDANCE SYSTEM",font=("calibri",40,"bold"),bg="White",fg="red")
        titlelbl.place(x=0,y=0,width=1280,height=45)

#time
        def time():
                string=strftime('%H:%M:%S %p')
                lbl.config(text=string)
                lbl.after(1000,time)

        lbl=Label(titlelbl,font=("calibri",14,"bold"),background="white",foreground="black")
        lbl.place(x=0,y=0,width=110,height=45)
        time()

#student button
        imgst=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\studimg.png")
        imgst=imgst.resize((150,150),Image.ANTIALIAS)
        self.photoimgst=ImageTk.PhotoImage(imgst)

        btn_stud=Button(bag_img,image=self.photoimgst,command=self.detail,cursor="hand2")
        btn_stud.place(x=160,y=100,width=150,height=150)     
        btn_stud1=Button(bag_img,text="Register Student",command=self.detail,cursor="hand2",font=("calibri",15,"bold"),bg="White",fg="black")
        btn_stud1.place(x=160,y=220,width=150,height=35)   

#Face Detector button
        imgfac=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\facedet.jpg")
        imgfac=imgfac.resize((150,150),Image.ANTIALIAS)
        self.photoimgfac=ImageTk.PhotoImage(imgfac)

        btn_detect=Button(bag_img,image=self.photoimgfac,command=self.recognize_data,cursor="hand2")
        btn_detect.place(x=430,y=100,width=150,height=150)     
        btn_detect1=Button(bag_img,text="Face Recognitizer",command=self.recognize_data,cursor="hand2",font=("calibri",15,"bold"),bg="White",fg="black")
        btn_detect1.place(x=430,y=220,width=150,height=35)    

#Attendance button
        imgattend=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\attend.jpg")
        imgattend=imgattend.resize((150,150),Image.ANTIALIAS)
        self.photoimgatt=ImageTk.PhotoImage(imgattend)

        btn_studat=Button(bag_img,image=self.photoimgatt,command=self.attendance_data,cursor="hand2")
        btn_studat.place(x=700,y=100,width=150,height=150)     
        btn_stud1at=Button(bag_img,text="Attendance",command=self.attendance_data,cursor="hand2",font=("calibri",15,"bold"),bg="White",fg="black")
        btn_stud1at.place(x=700,y=220,width=150,height=35)  

#Help button
        imghelp=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\helpin.png")
        imghelp=imghelp.resize((150,150),Image.ANTIALIAS)
        self.photoimghelp=ImageTk.PhotoImage(imghelp)

        btn_help=Button(bag_img,image=self.photoimghelp,command=self.helpit,cursor="hand2")
        btn_help.place(x=970,y=100,width=150,height=150)     
        btn_help1=Button(bag_img,text="Help Desk",command=self.helpit,cursor="hand2",font=("calibri",15,"bold"),bg="White",fg="black")
        btn_help1.place(x=970,y=220,width=150,height=35)     

#Train Face button
        imgtrain=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\trainin.jpg")
        imgtrain=imgtrain.resize((150,150),Image.ANTIALIAS)
        self.photoimgtrain=ImageTk.PhotoImage(imgtrain)

        btn_train=Button(bag_img,image=self.photoimgtrain,command=self.train_data,cursor="hand2")
        btn_train.place(x=160,y=300,width=150,height=150)     
        btn_train1=Button(bag_img,text="Train Data",command=self.train_data,cursor="hand2",font=("calibri",15,"bold"),bg="White",fg="black")
        btn_train1.place(x=160,y=420,width=150,height=35)     

#Photos button
        imgpht=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\photos.jpg")
        imgpht=imgpht.resize((150,150),Image.ANTIALIAS)
        self.photoimgpht=ImageTk.PhotoImage(imgpht)

        btn_photo=Button(bag_img,image=self.photoimgpht,command=self.open_image,cursor="hand2")
        btn_photo.place(x=430,y=300,width=150,height=150)     
        btn_photo1=Button(bag_img,text="Photos",command=self.open_image,cursor="hand2",font=("calibri",15,"bold"),bg="White",fg="black")
        btn_photo1.place(x=430,y=420,width=150,height=35)     

#Developer Info button
        imgdev=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\dev.jpg")
        imgdev=imgdev.resize((150,150),Image.ANTIALIAS)
        self.photoimgdev=ImageTk.PhotoImage(imgdev)

        btn_dev=Button(bag_img,image=self.photoimgdev,command=self.devloperinfo,cursor="hand2")
        btn_dev.place(x=700,y=300,width=150,height=150)     
        btn_dev1=Button(bag_img,text="Developer",command=self.devloperinfo,cursor="hand2",font=("calibri",15,"bold"),bg="White",fg="black")
        btn_dev1.place(x=700,y=420,width=150,height=35)  

#Exit button
        imgquit=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\exit.jpg")
        imgquit=imgquit.resize((150,150),Image.ANTIALIAS)
        self.photoimgquit=ImageTk.PhotoImage(imgquit)

        btn_exit=Button(bag_img,image=self.photoimgquit,command=self.exitit,cursor="hand2")
        btn_exit.place(x=970,y=300,width=150,height=150)     
        btn_exit1=Button(bag_img,text="Exit",command=self.exitit,cursor="hand2",font=("calibri",15,"bold"),bg="White",fg="black")
        btn_exit1.place(x=970,y=420,width=150,height=35)  

#Function Button
    def detail(self):
        self.new_window=Toplevel(self.root)
        self.app=Student_Details(self.new_window)


#photos function
    def open_image(self):
        os.startfile(r"C:\Users\nikhi\Python\FaceRecognition\Data")

#train function
    def train_data(self):
        self.new_window=Toplevel(self.root)
        self.app=Training(self.new_window)

#recognize function
    def recognize_data(self):
        self.new_window=Toplevel(self.root)
        self.app=Facedetecting(self.new_window)

#attendance function
    def attendance_data(self):
        self.new_window=Toplevel(self.root)
        self.app=Attend(self.new_window)

#developer function
    def devloperinfo(self):
        self.new_window=Toplevel(self.root)
        self.app=developer(self.new_window)

#help function
    def helpit(self):
        self.new_window=Toplevel(self.root)
        self.app=helpi(self.new_window)

#exit function
    def exitit(self):
        self.iExit=messagebox.askyesno("Face Recognition Attendance System","Are You Sure Want To Exit",parent=self.root)
        if self.iExit>0:
            self.root.destroy()
        else:
            return


if __name__ == "__main__":
    root=Tk()
    obj=Face_Recognize(root)
    root.mainloop()
    