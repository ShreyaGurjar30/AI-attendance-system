from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
from facial import Face_Recognize
import mysql.connector
import cv2
import os

def main():
    win=Tk()
    app=Loginsys(win)
    win.mainloop()

class Loginsys:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1275x910+0+0")
        self.root.title("Login Page")

#background
        bgimg=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\back.jpg")
        bgimg=bgimg.resize((1280,890),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(bgimg)

        bag_img=Label(self.root,image=self.photoimg4)
        bag_img.place(x=-9,y=0,width=1300,height=920)
        
        frame=Frame(self.root,bg="white")
        frame.place(x=475,y=115,width=340,height=450)

        imgtop=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\login.jpg")
        imgtop=imgtop.resize((85,85),Image.ANTIALIAS)
        self.photoimgtop=ImageTk.PhotoImage(imgtop)

        toplabel=Label(frame,image=self.photoimgtop)
        toplabel.place(x=130,y=15,width=85,height=85)

#Title
        strtlbl=Label(frame,text="Get Started",font=("calibri",16,"bold"),bg="white",fg="black")
        strtlbl.place(x=120,y=100)

        #username
        usrlabel=Label(self.root,text="Username:",font=("calibri",16,"bold"),bg="white",fg="black")
        usrlabel.place(x=490,y=250)

        self.usertb=ttk.Entry(self.root,width=29,font=("calibri",15,"bold"))
        self.usertb.place(x=495,y=280)

        #password
        passlabel=Label(self.root,text="Password:",font=("calibri",16,"bold"),bg="white",fg="black")
        passlabel.place(x=490,y=318)

        self.passtb=ttk.Entry(self.root,width=29,font=("calibri",15,"bold"),show="*")
        self.passtb.place(x=495,y=348)

#loginbutton 
        log_btn=Button(self.root,text="Login",command=self.loginit,font=("calibri",17,"bold"),fg="#2575fc",bg="#a6c1ee",width=11)
        log_btn.place(x=586,y=410,width=110,height=34)
#registerbutton 
        reg_btn=Button(self.root,text="New User Register",command=self.registerusr,font=("calibri",13,"bold"),fg="black",bg="white",borderwidth=0,width=11,activebackground="black",activeforeground="white")
        reg_btn.place(x=493,y=480,width=140,height=34)
#forgotpasswordbutton 
        reg_btn=Button(self.root,text="Forgot Password",command=self.forgot_pass,font=("calibri",13,"bold"),fg="black",bg="white",borderwidth=0,width=11,activebackground="black",activeforeground="white")
        reg_btn.place(x=485,y=520,width=138,height=34)

#register function
    def registerusr(self):
        self.new_window=Toplevel(self.root)
        self.app=Registerit(self.new_window)

#login function
    def loginit(self):
        if self.usertb.get()=="" or self.passtb.get()=="":
            messagebox.showerror("Error","Please Fill Proper Details",parent=self.root)
        elif self.usertb.get()=="Nikx" and self.passtb.get()=="procoder":
            messagebox.showinfo("Login","Login Successfully Done!",parent=self.root)
            self.new_window=Toplevel(self.root)
            self.app=Face_Recognize(self.new_window)    
        else:
            conn=mysql.connector.connect(host="localhost",user="root",password="",database="face_recognizer")
            my_cursor=conn.cursor()
            my_cursor.execute("select * from register where email=%s and pass=%s",(self.usertb.get(),self.passtb.get()))
            row=my_cursor.fetchone()
            if row==None:
                messagebox.showerror("Error","Invalid Username And Password",parent=self.root)
            else:
                open_main=messagebox.askyesno("Ask Tes Or No","Access Only Admin",parent=self.root)
                if open_main>0:
                    self.new_window=Toplevel(self.root)
                    self.app=Face_Recognize(self.new_window)
                else:
                    if not open_main:
                        return
            conn.commit()
            conn.close()

#reset password
    def reset_pass(self):
            if self.sec_combo.get()=="Select Question":
                messagebox.showerror("Error","Select The Security Question",parent=self.root2)
            elif self.anstb.get()=="":
                messagebox.showerror("Error","Please Enter Valid Answer",parent=self.root2)
            elif self.newpasstb.get()=="":
                messagebox.showerror("Error","Please Enter New Password ",parent=self.root2)
            elif len(self.newpasstb.get())<8:
                messagebox.showerror("Error","Please Enter Password More Than 8 Characters",parent=self.root2)
            else:
                conn=mysql.connector.connect(host="localhost",user="root",password="",database="face_recognizer")
                my_cursor=conn.cursor()
                query=("select * from register where email=%s and secQ=%s and secA=%s")
                value=(self.usertb.get(),self.sec_combo.get(),self.anstb.get())
                my_cursor.execute(query,value)
                row=my_cursor.fetchone()
                if row==None:
                    messagebox.showerror("Error","Please Enter Correct Answer",parent=self.root2)
                else:
                    query2=("update register set pass=%s where email=%s")
                    value=(self.newpasstb.get(),self.usertb.get())
                    my_cursor.execute(query2,value)
                    conn.commit()
                    conn.close()
                    messagebox.showinfo("Success","Your Password Have Been Reset Successfully!",parent=self.root2)

#forgot password
    def forgot_pass(self):
        if self.usertb.get()=="":
            messagebox.showerror("Error","Enter Valid Username",parent=self.root)
        else:
            conn=mysql.connector.connect(host="localhost",user="root",password="",database="face_recognizer")
            my_cursor=conn.cursor()
            query=("select * from register where email=%s")
            value=(self.usertb.get(),)
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()
            if row==None:
                messagebox.showerror("Error","Please Enter Valid Username")
            else:
                conn.close()
                self.root2=Toplevel()
                self.root2.title("Forgot Password")
                self.root2.geometry("340x450+475+115")

                titlelbl=Label(self.root2,text="FORGOT PASSWORD",font=("calibri",17,"bold"),bg="White",fg="black")
                titlelbl.place(x=0,y=10,relwidth=1)

                #Security
                seclabel=Label(self.root2,text="Select Security Question",font=("calibri",16,"bold"),bg="White")
                seclabel.place(x=30,y=60)

                self.sec_combo=ttk.Combobox(self.root2,font=("calibri",14,"bold"),state="readonly",width=25)
                self.sec_combo["values"]=("Select Question","Your Birth Date","Favourite Anime","Favourite Subject")
                self.sec_combo.current(0)
                self.sec_combo.place(x=30,y=95)

                #Ans
                anslabel=Label(self.root2,text="Security Answer",font=("calibri",16,"bold"),bg="White")
                anslabel.place(x=30,y=135)

                self.anstb=ttk.Entry(self.root2,width=27,font=("calibri",15,"bold"))
                self.anstb.place(x=30,y=165)

                #new password
                secanslabel=Label(self.root2,text="New Password",font=("calibri",16,"bold"),bg="White")
                secanslabel.place(x=30,y=205)

                self.newpasstb=ttk.Entry(self.root2,width=27,font=("calibri",15,"bold"))
                self.newpasstb.place(x=30,y=235)

                #reset button
                self.newpass_btn=Button(self.root2,command=self.reset_pass,text="Reset Password",font=("calibri",15,"bold"),fg="white",bg="black",width=13)
                self.newpass_btn.place(x=100,y=330)

class Registerit:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1275x910+0+0")
        self.root.title("Register User")

#variables
        self.var_fname=StringVar()
        self.var_lname=StringVar()
        self.var_contac=StringVar()
        self.var_email=StringVar()
        self.var_secQ=StringVar()
        self.var_secA=StringVar()
        self.var_pass=StringVar()
        self.var_confpass=StringVar()

#background
        bgimg=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\register1.jpg")
        bgimg=bgimg.resize((1280,800),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(bgimg)

        bag_img=Label(self.root,image=self.photoimg4)
        bag_img.place(x=-9,y=0,width=1290,height=800)

        titlelbl=Label(self.root,text="REGISTERATION",font=("calibri",45,"bold"),bg="White",fg="black")
        titlelbl.place(x=-5,y=25,width=1290,height=45)

        main_frame=Frame(self.root,bg="white")
        main_frame.place(x=300,y=95,width=690,height=485)

        reglbl=Label(main_frame,text="Register Here",font=("calibri",25,"bold"),bg="White",fg="black")
        reglbl.place(x=20,y=14)


        #Name
        namelabel=Label(main_frame,text="First Name",font=("calibri",16,"bold"),bg="White")
        namelabel.place(x=30,y=69)

        self.nametb=ttk.Entry(main_frame,textvariable=self.var_fname,width=27,font=("calibri",15,"bold"))
        self.nametb.place(x=32,y=102)

        #LastName
        namelaslabel=Label(main_frame,text="Last Name",font=("calibri",16,"bold"),bg="White")
        namelaslabel.place(x=380,y=69)

        self.namelastb=ttk.Entry(main_frame,textvariable=self.var_lname,width=27,font=("calibri",15,"bold"))
        self.namelastb.place(x=382,y=102)

        #Contact
        conlabel=Label(main_frame,text="Contact",font=("calibri",16,"bold"),bg="White")
        conlabel.place(x=30,y=135)

        self.contb=ttk.Entry(main_frame,textvariable=self.var_contac,width=27,font=("calibri",15,"bold"))
        self.contb.place(x=32,y=167)
        
        #Email
        emalabel=Label(main_frame,text="Email Id",font=("calibri",16,"bold"),bg="White")
        emalabel.place(x=380,y=135)

        self.ematb=ttk.Entry(main_frame,textvariable=self.var_email,width=27,font=("calibri",15,"bold"))
        self.ematb.place(x=382,y=167)

        #Security
        seclabel=Label(main_frame,text="Select Security Question",font=("calibri",16,"bold"),bg="White")
        seclabel.place(x=30,y=203)

        sec_combo=ttk.Combobox(main_frame,textvariable=self.var_secQ,font=("times new roman",14,"bold"),state="readonly",width=25)
        sec_combo["values"]=("Select Question","Your Birth Date","Favourite Anime","Favourite Subject")
        sec_combo.current(0)
        sec_combo.place(x=32,y=239)

        #Ans
        anslabel=Label(main_frame,text="Security Answer",font=("calibri",16,"bold"),bg="White")
        anslabel.place(x=380,y=203)

        self.anstb=ttk.Entry(main_frame,textvariable=self.var_secA,width=27,font=("calibri",15,"bold"))
        self.anstb.place(x=382,y=239)

        #Password
        passlabel=Label(main_frame,text="Password",font=("calibri",16,"bold"),bg="White")
        passlabel.place(x=30,y=269)

        self.passtb=ttk.Entry(main_frame,show="*",textvariable=self.var_pass,width=27,font=("calibri",15,"bold"))
        self.passtb.place(x=32,y=305)

        #Confirm
        conflabel=Label(main_frame,text="Confirm Password",font=("calibri",16,"bold"),bg="White")
        conflabel.place(x=380,y=269)

        self.conftb=ttk.Entry(main_frame,show="*",textvariable=self.var_confpass,width=27,font=("calibri",15,"bold"))
        self.conftb.place(x=382,y=305)

        #checkbutton
        self.varcond=IntVar()
        chk_btn=Checkbutton(main_frame,variable=self.varcond,text="I Agree The Terms & Conditions",font=("calibri",14,"bold"),bg="white",onvalue=1,offvalue=0)
        chk_btn.place(x=30,y=350)

#loginbutton 
        log_btn=Button(main_frame,command=self.register_data,text="Register Now",font=("calibri",17,"bold"),fg="white",bg="black",width=11)
        log_btn.place(x=195,y=420,width=150,height=34)
#registerbutton 
        reg_btn=Button(main_frame,text="Login Now",command=self.loginin,font=("calibri",17,"bold"),fg="white",bg="black",width=11)
        reg_btn.place(x=345,y=420,width=150,height=34)
#login function
    def loginin(self):
        self.new_window=Toplevel(self.root)
        self.app=Loginsys(self.new_window)
#register function
    def register_data(self):
            if self.var_fname.get()=="" or self.var_secQ.get()=="Select Question" or self.var_pass.get()=="":
                messagebox.showerror("Error","Please Fill Proper Data",parent=self.root)
            elif self.var_pass.get()!=self.var_confpass.get():
                messagebox.showerror("Error","Password And Confirm Password Should Be Same",parent=self.root)
            elif self.varcond.get()==0:
                messagebox.showerror("Error","Please Agree Our Terms And Conditions",parent=self.root)
            elif len(self.var_pass.get())<(8):
                messagebox.showerror("Error","Please Enter Password Greater Than 8 Characters",parent=self.root)
            else:
                try:
                    conn=mysql.connector.connect(host="localhost",username="root",password="nikhil1@1",database="face_recognize")
                    my_cursor=conn.cursor()
                    query=("select * from register where email=%s")
                    value=(self.var_email.get(),)
                    my_cursor.execute(query,value)
                    row=my_cursor.fetchone()
                    if row!=None:
                        messagebox.showerror("Error","User Already Exist,Try Other Gmail Account",parent=self.root)
                    else:
                        my_cursor.execute("insert into register values(%s,%s,%s,%s,%s,%s,%s)",(self.var_fname.get(),self.var_lname.get(),self.var_contac.get(),self.var_email.get(),self.var_secQ.get(),self.var_secA.get(),self.var_pass.get()))
                        messagebox.showinfo("Success","User Registeration Successfull",parent=self.root)
                    conn.commit()
                    conn.close()
                except Exception as ex:
                    messagebox.showerror("Error",f"Due To:{str(ex)}",parent=self.root)
                

#login function
    def loginin(self):
        self.new_window=Toplevel(self.root)
        self.app=Loginsys(self.new_window)


if __name__ == "__main__":
    main()