from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import cv2
from time import strftime
from datetime import datetime
import os
import mysql.connector
import csv
import numpy as np
# import face_recognition

class Facedetecting:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1275x910+0+0")
        self.root.title("Facial Recognition System")

        titlelbl=Label(self.root,text="DETECT YOUR FACE",font=("calibri",45,"bold"),bg="White",fg="red")
        titlelbl.place(x=-5,y=0,width=1290,height=45)

# 1st
        imgtop=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\load1.jpg")
        imgtop=imgtop.resize((640,650),Image.ANTIALIAS)
        self.photoimgtop=ImageTk.PhotoImage(imgtop)

        toplabel=Label(self.root,image=self.photoimgtop)
        toplabel.place(x=-8,y=47,width=640,height=650)
#2nd
        imgbot=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\load.jpg")
        imgbot=imgbot.resize((645,650),Image.ANTIALIAS)
        self.photoimgbot=ImageTk.PhotoImage(imgbot)

        botlabel=Label(self.root,image=self.photoimgbot)
        botlabel.place(x=635,y=47,width=645,height=650)

#button
        btn1=Button(self.root,text="Face Recognition",command=self.Recogface,cursor="hand2",font=("calibri",25,"bold"),bg="white",fg="black")
        btn1.place(x=820,y=65,width=274,height=40)
#mark attendance function
    def markattendance(self,n1,e,d):
        with open(r"D:\Degree\Face-Recognition\Finallproject\FaceRecognition\Attendance.csv","r+",newline="\n") as f:
            myData=f.readlines()
            nameList=[]
            for line in myData:
                entry=line.split((","))
                nameList.append(entry[0])
            if( (e not in nameList) and (d not in nameList) and (n1 not in nameList) ):
                now=datetime.now()
                d1=now.strftime("%d/%m/%Y")
                dtString=now.strftime("%H:%M:%S")
                f.writelines(f"\n{n1},{e},{d},{dtString},{d1},Present")

# (n1 not in nameList) 
#recognization function
    def Recogface(self):
        def draw_rect(img,classifier,scaleFactor,minNeighbors,color,text,clf):
            gray_image=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
            features=classifier.detectMultiScale(gray_image,scaleFactor,minNeighbors)

            coord=[]

            for (x,y,w,h) in features:
                cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255),2)
                id,predict=clf.predict(gray_image[y:y+h,x:x+w])
                confidence=int((100*(1-predict/300)))

                conn=mysql.connector.connect(host="localhost",user="root",password="",database='face_recognizer')
                my_cursor=conn.cursor()

                my_cursor.execute("select name from student1 where enrollid="+str(id))
                n1=my_cursor.fetchone()
                n1="+".join(n1)

                # my_cursor.execute("select rollno from student1 where enrollid="+str(id))
                # r=my_cursor.fetchone()
                # r="+".join(r)

                my_cursor.execute("select enrollid from student1 where enrollid="+str(id))
                e=my_cursor.fetchone()
                e="+".join(e)

                my_cursor.execute("select Dept from student1 where enrollid="+str(id))
                d=my_cursor.fetchone()
                d=" +".join(d)

                if confidence>79:
                    cv2.putText(img,f"Name:{n1}",(x,y-69),cv2.FONT_HERSHEY_COMPLEX,0.8,(255,255,255),2)
                    # cv2.putText(img,f"Roll No:{r}",(x,y-49),cv2.FONT_HERSHEY_COMPLEX,0.8,(255,255,255),2)
                    cv2.putText(img,f"Enrollment:{e}",(x,y-29),cv2.FONT_HERSHEY_COMPLEX,0.8,(255,255,255),2)
                    cv2.putText(img,f"Department:{d}",(x,y-5),cv2.FONT_HERSHEY_COMPLEX,0.8,(255,255,255),2)
                    self.markattendance(n1,e,d)
                else:
                    cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255),2)
                    cv2.putText(img,"Unknown Face:",(x,y-5),cv2.FONT_HERSHEY_COMPLEX,0.8,(0,0,255),2)

                coord=[x,y,w,h]
            return coord
        
        def recognize(img,clf,faceCascade):
            coord=draw_rect(img,faceCascade,1.1,10,(255,255,255),"Face",clf)
            return img
        
        faceCascade=cv2.CascadeClassifier(r'D:\Degree\Face-Recognition\Finallproject\FaceRecognition\haarcascade_frontalface_default.xml')
        clf=cv2.face.LBPHFaceRecognizer_create()
        clf.read(r"D:\Degree\Face-Recognition\Finallproject\FaceRecognition\Classifier.xml")

        video_cap=cv2.VideoCapture(0)

        while True:
            ret,img=video_cap.read()
            img=recognize(img,clf,faceCascade)
            cv2.imshow("Welcome To Face Recognition",img)

            if cv2.waitKey(1)==13:
                break
        video_cap.release()
        cv2.destroyAllWindows()
        


if __name__ == "__main__":
    root=Tk()
    obj=Facedetecting(root)
    root.mainloop()