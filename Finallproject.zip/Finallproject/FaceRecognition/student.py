from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
import cv2
import os

class Student_Details:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1275x910+0+0")
        self.root.title("Facial Recognition System")

        #variables
        self.var_Dept=StringVar()
        self.var_course=StringVar()
        self.var_year=StringVar()
        self.var_Sem=StringVar()
        self.var_enrollid=StringVar()
        self.var_name=StringVar()
        self.var_rollno=StringVar()
        self.var_mobile=StringVar()
        self.var_gender=StringVar()
        self.var_dob=StringVar()
        self.var_email=StringVar()
        self.var_addr=StringVar()
       

#1st
        img=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\stud1.png")
        img=img.resize((440,130),Image.ANTIALIAS)
        self.photoimg=ImageTk.PhotoImage(img)

        firstlabel=Label(self.root,image=self.photoimg)
        firstlabel.place(x=0,y=0,width=440,height=130)
#2nd
        img2=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\stud2.png")
        img2=img2.resize((440,130),Image.ANTIALIAS)
        self.photoimg2=ImageTk.PhotoImage(img2)

        seclabel=Label(self.root,image=self.photoimg2)
        seclabel.place(x=440,y=0,width=440,height=130)
#3rd
        img3=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\stud3.jpg")
        img3=img3.resize((440,130),Image.ANTIALIAS)
        self.photoimg3=ImageTk.PhotoImage(img3)

        thirdlabel=Label(self.root,image=self.photoimg3)
        thirdlabel.place(x=900,y=0,width=440,height=130)

#background
        bgimg=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\bgstuddet.jpg")
        bgimg=bgimg.resize((1480,530),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(bgimg)

        bag_img=Label(self.root,image=self.photoimg4)
        bag_img.place(x=0,y=90,width=1480,height=590)

#Title
        titlelbl=Label(bag_img,text="STUDENT REGISTERATION",font=("calibri",35,"bold"),bg="White",fg="black")
        titlelbl.place(x=-5,y=0,width=1290,height=45)

#Main Frame
        main_frame=Frame(bag_img,bd=2,bg="White")
        main_frame.place(x=10,y=55,width=1255,height=490)

#Left Frame
        left_frame=LabelFrame(main_frame,bd=2,bg="White",relief=RIDGE,text="Student Details",font=("calibri",15,"bold"))
        left_frame.place(x=10,y=10,width=600,height=455)

#CurrentCourse Frame
        course_frame=LabelFrame(left_frame,bd=2,bg="White",relief=RIDGE,text="Current Course",font=("calibri",12,"bold"))
        course_frame.place(x=12,y=3,width=573,height=110)
#Department
        deptlabel=Label(course_frame,text="Department",font=("calibri",11,"bold"),bg="White")
        deptlabel.grid(row=0,column=0,padx=10,sticky=W)

        dept_combo=ttk.Combobox(course_frame,textvariable=self.var_Dept,font=("times new roman",11,"bold"),state="readonly",width=16)
        dept_combo["values"]=("Select Department","Computer","Civil","Mechanical","IT","Electrical")
        dept_combo.current(0)
        dept_combo.grid(row=0,column=1,padx=2,pady=10,sticky=W)
#CourseYear
        yearlabel=Label(course_frame,text="Year",font=("calibri",11,"bold"),bg="White")
        yearlabel.grid(row=0,column=2,padx=10,sticky=W)

        year_combo=ttk.Combobox(course_frame,textvariable=self.var_course,font=("times new roman",11,"bold"),state="readonly",width=16)
        year_combo["values"]=("Select Course","FY","SY","DSY","TY","BE")
        year_combo.current(0)
        year_combo.grid(row=0,column=3,padx=2,pady=10,sticky=W)
#Year
        acdyearlabel=Label(course_frame,text="AcademicYear",font=("calibri",11,"bold"),bg="White")
        acdyearlabel.grid(row=1,column=0,padx=10,sticky=W)

        acdyear_combo=ttk.Combobox(course_frame,textvariable=self.var_year,font=("times new roman",11,"bold"),state="readonly",width=16)
        acdyear_combo["values"]=("Academic Year","2020-21","2021-22","2022-23","2023-24")
        acdyear_combo.current(0)
        acdyear_combo.grid(row=1,column=1,padx=2,pady=10,sticky=W)
#Semester
        semlabel=Label(course_frame,text="Semester",font=("calibri",11,"bold"),bg="White")
        semlabel.grid(row=1,column=2,padx=10,sticky=W)

        sem_combo=ttk.Combobox(course_frame,textvariable=self.var_Sem,font=("times new roman",11,"bold"),state="readonly",width=16)
        sem_combo["values"]=("Select Semester","First","Second","Third","Fourth","Fifth","Sixth")
        sem_combo.current(0)
        sem_combo.grid(row=1,column=3,padx=2,pady=10,sticky=W)

#StudentInfo Frame  
        stud_frame=LabelFrame(left_frame,bd=2,bg="White",relief=RIDGE,text="Student Information",font=("calibri",12,"bold"))
        stud_frame.place(x=12,y=125,width=573,height=235)
        #enrollid
        enrollabel=Label(stud_frame,text="Enrollment No",font=("calibri",12,"bold"),bg="White")
        enrollabel.grid(row=0,column=0,padx=10,pady=15,sticky=W)

        enrollid=ttk.Entry(stud_frame,textvariable=self.var_enrollid,width=16,font=("calibri",12,"bold"))
        enrollid.grid(row=0,column=1,padx=10,pady=15,sticky=W)
        #name
        namelabel=Label(stud_frame,text="Student Name",font=("calibri",12,"bold"),bg="White")
        namelabel.grid(row=0,column=2,padx=10,pady=10,sticky=W)

        namest=ttk.Entry(stud_frame,textvariable=self.var_name,width=16,font=("calibri",12,"bold"))
        namest.grid(row=0,column=3,padx=10,pady=10,sticky=W)
        #Roll No
        rolllabel=Label(stud_frame,text="Roll Number",font=("calibri",12,"bold"),bg="White")
        rolllabel.grid(row=1,column=0,padx=10,pady=10,sticky=W)

        studroll=ttk.Entry(stud_frame,textvariable=self.var_rollno,width=16,font=("calibri",12,"bold"))
        studroll.grid(row=1,column=1,padx=10,pady=10,sticky=W)
        #Mobile No
        moblabel=Label(stud_frame,text="Mobile Number",font=("calibri",12,"bold"),bg="White")
        moblabel.grid(row=1,column=2,padx=10,pady=10,sticky=W)

        studmob=ttk.Entry(stud_frame,textvariable=self.var_mobile,width=16,font=("calibri",12,"bold"))
        studmob.grid(row=1,column=3,padx=10,pady=10,sticky=W)
        #Gender
        genlabel=Label(stud_frame,text="Gender",font=("calibri",12,"bold"),bg="White")
        genlabel.grid(row=2,column=0,padx=10,pady=10,sticky=W)

        gen_combo=ttk.Combobox(stud_frame,textvariable=self.var_gender,font=("times new roman",11,"bold"),state="readonly",width=14)
        gen_combo["values"]=("Select Gender","Male","Female","Others")
        gen_combo.current(0)
        gen_combo.grid(row=2,column=1,padx=10,pady=10,sticky=W)
        #Email
        maillabel=Label(stud_frame,text="Email Id",font=("calibri",12,"bold"),bg="White")
        maillabel.grid(row=2,column=2,padx=10,pady=10,sticky=W)

        studmail=ttk.Entry(stud_frame,textvariable=self.var_email,width=16,font=("calibri",12,"bold"))
        studmail.grid(row=2,column=3,padx=10,pady=10,sticky=W)
        #Date Of Birth
        doblabel=Label(stud_frame,text="Date Of Birth",font=("calibri",12,"bold"),bg="White")
        doblabel.grid(row=3,column=0,padx=10,pady=10,sticky=W)

        studdob=ttk.Entry(stud_frame,textvariable=self.var_dob,width=16,font=("calibri",12,"bold"))
        studdob.grid(row=3,column=1,padx=10,pady=10,sticky=W)
        #Address
        addlabel=Label(stud_frame,text="Address",font=("calibri",12,"bold"),bg="White")
        addlabel.grid(row=3,column=2,padx=10,pady=10,sticky=W)

        studadd=ttk.Entry(stud_frame,textvariable=self.var_addr,width=16,font=("calibri",12,"bold"))
        studadd.grid(row=3,column=3,padx=10,pady=10,sticky=W)
        #RadioButton
        self.var_radio1=StringVar()
        radiobtn1=ttk.Radiobutton(stud_frame,variable=self.var_radio1,text="Take Photo Sample",value="YES")
        radiobtn1.grid(row=4,column=0)
        radiobtn2=ttk.Radiobutton(stud_frame,variable=self.var_radio1,text="No Photo Sample",value="NO")
        radiobtn2.grid(row=4,column=1)

#Button Frame
        btn_frame=LabelFrame(left_frame,bd=2,bg="White",relief=RIDGE)
        btn_frame.place(x=12,y=358,width=573,height=55)
        #save
        save_btn=Button(btn_frame,text="Save",command=self.add_data,font=("calibri",10,"bold"),bg="black",fg="white",width=19)
        save_btn.grid(row=0,column=0)
        #update
        update_btn=Button(btn_frame,text="Update",command=self.update_data,font=("calibri",10,"bold"),bg="black",fg="white",width=19)
        update_btn.grid(row=0,column=1)
        #delete
        del_btn=Button(btn_frame,text="Delete",command=self.delete_data,font=("calibri",10,"bold"),bg="black",fg="white",width=19)
        del_btn.grid(row=0,column=2)
        #reset
        reset_btn=Button(btn_frame,text="Reset",command=self.reset_data,font=("calibri",10,"bold"),bg="black",fg="white",width=19)
        reset_btn.grid(row=0,column=4)


        btn2_frame=LabelFrame(left_frame,bd=2,bg="White",relief=RIDGE)
        btn2_frame.place(x=12,y=385,width=573,height=28)
        #takephoto
        reset_btn=Button(btn2_frame,text="Take Photo",command=self.generate_dataset,font=("calibri",10,"bold"),bg="black",fg="white",width=40)
        reset_btn.grid(row=0,column=0)
        #updatephoto
        reset_btn=Button(btn2_frame,text="Update Photo",font=("calibri",10,"bold"),bg="black",fg="white",width=39)
        reset_btn.grid(row=0,column=1)


#Right Frame
        right_frame=LabelFrame(main_frame,bd=2,bg="White",relief=RIDGE,text="Student Details",font=("calibri",15,"bold"))
        right_frame.place(x=640,y=10,width=600,height=455)
        #search
        search_frame=LabelFrame(right_frame,bd=2,bg="White",relief=RIDGE,text="Search System",font=("calibri",15,"bold"))
        search_frame.place(x=12,y=3,width=573,height=80)

        searchlabel=Label(search_frame,text="Search By",font=("calibri",12,"bold"),bg="White")
        searchlabel.grid(row=0,column=0,padx=10,pady=10,sticky=W)

        search_combo=ttk.Combobox(search_frame,font=("times new roman",12,"bold"),state="readonly",width=13)
        search_combo["values"]=("Select","Roll No","Enrollment No","Name")
        search_combo.current(0)
        search_combo.grid(row=0,column=1,padx=2,pady=10,sticky=W)
        #textbox
        searchst=ttk.Entry(search_frame,width=15,font=("calibri",12,"bold"))
        searchst.grid(row=0,column=2,padx=10,pady=10,sticky=W)
        #search
        search_btn=Button(search_frame,text="Search",font=("calibri",10,"bold"),bg="black",fg="white",width=12)
        search_btn.grid(row=0,column=3)
        #showall
        showall_btn=Button(search_frame,text="Show All",font=("calibri",10,"bold"),bg="black",fg="white",width=12)
        showall_btn.grid(row=0,column=4)

        #resulttable
        table_frame=Label(right_frame,bd=2,bg="White",relief=RIDGE)
        table_frame.place(x=12,y=105,width=573,height=240)

        scroll_x=ttk.Scrollbar(table_frame,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(table_frame,orient=VERTICAL)

        self.student_table=ttk.Treeview(table_frame,column=("Dept","course","year","Sem","enrollid","name","rollno","mobile","gender","dob","email","addr","photo"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_x.config(command=self.student_table.xview)
        scroll_y.config(command=self.student_table.yview)

        self.student_table.heading("Dept",text="Department")
        self.student_table.heading("course",text="Course")
        self.student_table.heading("year",text="AcademicYear")
        self.student_table.heading("Sem",text="Semester")
        self.student_table.heading("enrollid",text="Enrollment No")
        self.student_table.heading("name",text="Student Name")
        self.student_table.heading("rollno",text="Roll No")
        self.student_table.heading("mobile",text="Mobile No")
        self.student_table.heading("gender",text="Gender")
        self.student_table.heading("dob",text="Date Of Birth")
        self.student_table.heading("email",text="Email Id")
        self.student_table.heading("addr",text="Address")
        self.student_table.heading("photo",text="PhotoSampledStatus")

        self.student_table["show"]="headings"

        self.student_table.column("Dept",width=100)
        self.student_table.column("course",width=100)
        self.student_table.column("year",width=100)
        self.student_table.column("Sem",width=100)
        self.student_table.column("enrollid",width=100)
        self.student_table.column("name",width=100)
        self.student_table.column("rollno",width=100)
        self.student_table.column("mobile",width=100)
        self.student_table.column("gender",width=100)
        self.student_table.column("dob",width=100)
        self.student_table.column("email",width=100)
        self.student_table.column("addr",width=100)
        self.student_table.column("photo",width=140)

        self.student_table.pack(fill=BOTH,expand=1)
        self.student_table.bind("<ButtonRelease>",self.get_cursor)
        self.fetch_data()

#Function Button
    def add_data(self):
        if self.var_Dept.get()=="Select Department" or self.var_name.get()=="" or self.var_enrollid.get()=="" or self.var_rollno.get()=="":
            messagebox.showerror("Error","Enter Data Properly",parent=self.root)
        else:
            try: 
                conn=mysql.connector.connect(host="localhost",user="root",password="",database="face_recognizer")
                my_cursor=conn.cursor()
                my_cursor.execute("insert into student1 values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",(self.var_Dept.get(),self.var_course.get(),self.var_year.get(),self.var_Sem.get(),self.var_enrollid.get(),self.var_name.get(),self.var_rollno.get(),self.var_gender.get(),self.var_dob.get(),self.var_email.get(),self.var_mobile.get(),self.var_addr.get(),self.var_radio1.get()))

                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success","Sudents Details Successfully Registered",parent=self.root)
            except Exception as ex:
                messagebox.showerror("Error",f"Due To:{str(ex)}",parent=self.root)

#fetch Data
    def fetch_data(self):
        conn=mysql.connector.connect(host="localhost",user="root",password="",database="face_recognizer")
        my_cursor=conn.cursor()
        my_cursor.execute("Select * from student1")
        data=my_cursor.fetchall()
        if len(data)!=0:
            self.student_table.delete(*self.student_table.get_children())
            for i in data:
                self.student_table.insert("",END,values=i)
        conn.commit()
        conn.close()

#get cursor
    def get_cursor(self,event=""):
        cursor_focus=self.student_table.focus()
        content=self.student_table.item(cursor_focus)
        data=content["values"]

        self.var_Dept.set(data[0]),
        self.var_course.set(data[1]),
        self.var_year.set(data[2]),
        self.var_Sem.set(data[3]),
        self.var_enrollid.set(data[4]),
        self.var_name.set(data[5]),
        self.var_rollno.set(data[6]),
        self.var_mobile.set(data[7]),
        self.var_gender.set(data[8]),
        self.var_dob.set(data[9]),
        self.var_email.set(data[10]),
        self.var_addr.set(data[11]),
        self.var_radio1.set(data[12])

#Update Data
    def update_data(self):
        if self.var_Dept.get()=="Select Department" or self.var_name.get()=="" or self.var_enrollid.get()=="" or self.var_rollno.get()=="":
            messagebox.showerror("Error","Enter Data Properly",parent=self.root)
        else:
            try:
                update=messagebox.askyesno("Update","Do You Want To Update Student Detail",parent=self.root)
                if update>0:
                    conn=mysql.connector.connect(host="localhost",user="root",password="",database='face_recognizer')
                    my_cursor=conn.cursor()
                    my_cursor.execute("update student1 set Dept=%s,course=%s,year=%s,Sem=%s,name=%s,rollno=%s,mobile=%s,gender=%s,dob=%s,email=%s,addr=%s,photo=%s WHERE enrollid=%s",(self.var_Dept.get(),self.var_course.get(),self.var_year.get(),self.var_Sem.get(),self.var_enrollid.get(),self.var_name.get(),self.var_rollno.get(),self.var_gender.get(),self.var_dob.get(),self.var_email.get(),self.var_mobile.get(),self.var_addr.get(),self.var_radio1.get()))
                else:
                    if not update:
                        return
                messagebox.showinfo("Success","Student Details Successfully Updated",parent=self.root)   
                conn.commit()
                self.fetch_data()
                conn.close()     
            except Exception as ex:
                messagebox.showerror("Error",f"Due To:{str(ex)}",parent=self.root)

#Delete Data
    def delete_data(self):
        if self.var_enrollid.get()=="":
            messagebox.showerror("Error","Enrollment No Is Mandatory",parent=self.root)
        else:
            try:
                delete=messagebox.askyesno("Student Delete Page","Do You Want To Delete This Student Details",parent=self.root)
                if delete>0:
                    conn=mysql.connector.connect(host="localhost",user="root",password="",database='face_recognizer')
                    my_cursor=conn.cursor()
                    sql="delete from student1 where enrollid=%s"
                    val=(self.var_enrollid.get(),)
                    my_cursor.execute(sql,val)
                else:
                    if not delete:
                        return
                messagebox.showinfo("Success","Student Details Successfully Deleted",parent=self.root)   
                conn.commit()
                self.fetch_data()
                conn.close()     
            except Exception as ex:
                messagebox.showerror("Error",f"Due To:{str(ex)}",parent=self.root)

#reset function
    def reset_data(self):
        self.var_Dept.set("Select Department")
        self.var_course.set("Select Course")
        self.var_year.set("Academic Year")
        self.var_Sem.set("Select Semester")
        self.var_enrollid.set("")
        self.var_name.set("")
        self.var_rollno.set("")
        self.var_mobile.set("")
        self.var_gender.set("Select Gender")
        self.var_dob.set("")
        self.var_email.set("")
        self.var_addr.set("")
        self.var_radio1.set("")

#generate Dataset / Photo samples
    def generate_dataset(self):
        if self.var_Dept.get()=="Select Department" or self.var_name.get()=="" or self.var_enrollid.get()=="" or self.var_rollno.get()=="":
            messagebox.showerror("Error","Enter Data Properly",parent=self.root)
        else:
            try:
                conn=mysql.connector.connect(host="localhost",user="root",password="",database='face_recognizer')
                my_cursor=conn.cursor()
                my_cursor.execute("select * from student1")
                myresult=my_cursor.fetchall()
                id=0
                for x in myresult:
                    id+=1
                my_cursor.execute("update student1 set Dept=%s,course=%s,year=%s,Sem=%s,name=%s,rollno=%s,mobile=%s,gender=%s,dob=%s,email=%s,addr=%s,photo=%s WHERE enrollid=%s",(self.var_Dept.get(),self.var_course.get(),self.var_year.get(),self.var_Sem.get(),self.var_name.get(),self.var_rollno.get(),self.var_gender.get(),self.var_dob.get(),self.var_email.get(),self.var_mobile.get(),self.var_addr.get(),self.var_radio1.get(),self.var_enrollid.get()==id+1))
                conn.commit()
                self.fetch_data()
                self.reset_data()
                conn.close()

                #load from open cv
                face_classified=cv2.CascadeClassifier(r'D:\Degree\Face-Recognition\Finallproject\FaceRecognition\haarcascade_frontalface_default.xml')
                def face_cropped(img):
                    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
                    faces=face_classified.detectMultiScale(gray,1.3,5)

                    for (x,y,w,h) in faces:
                        face_cropped=img[y:y+h,x:x+w]
                        return face_cropped
                    
                capture=cv2.VideoCapture(0)
                img_id=0
                while TRUE:
                    ret,frame=capture.read()
                    if face_cropped(frame) is not None:
                        img_id+=1
                        face=cv2.resize(face_cropped(frame),(450,450))
                        face=cv2.cvtColor(face,cv2.COLOR_BGR2GRAY)
                        file_path=r"D:\Degree\Face-Recognition\Finallproject\FaceRecognition\Data\user."+str(id)+"."+str(img_id)+".jpg"
                        cv2.imwrite(file_path,face)
                        cv2.putText(face,str(img_id),(50,50),cv2.FONT_HERSHEY_COMPLEX,2,(0,255.0),2)
                        cv2.imshow("Cropped Faces",face)

                    if cv2.waitKey(1)==13 or int(img_id)==80:
                        break
                capture.release()
                cv2.destroyAllWindows()
                messagebox.showinfo("Result","Generating Datasets Completed!",parent=self.root)

            except Exception as ex:
                messagebox.showerror("Error",f"Due To:{str(ex)}",parent=self.root)



if __name__ == "__main__":
    root=Tk()
    obj=Student_Details(root)
    root.mainloop()