from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
import cv2
import os
import csv
from tkinter import filedialog

mydata=[]
class Attend:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1275x910+0+0")
        self.root.title("Attendance Management System")

#Variables
        self.var_name=StringVar()
        self.var_enrollid=StringVar()
        self.var_rollno=StringVar()
        self.var_dept=StringVar()
        self.var_date=StringVar()
        self.var_time=StringVar()
        self.var_status=StringVar()

#1st
        img=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\pt.png")
        img=img.resize((640,130),Image.ANTIALIAS)
        self.photoimg=ImageTk.PhotoImage(img)

        firstlabel=Label(self.root,image=self.photoimg)
        firstlabel.place(x=0,y=0,width=640,height=130)
#2nd
        img2=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\stud2.png")
        img2=img2.resize((640,130),Image.ANTIALIAS)
        self.photoimg2=ImageTk.PhotoImage(img2)

        seclabel=Label(self.root,image=self.photoimg2)
        seclabel.place(x=645,y=0,width=640,height=130)

#background
        bgimg=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\attend.jpg")
        bgimg=bgimg.resize((1480,570),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(bgimg)

        bag_img=Label(self.root,image=self.photoimg4)
        bag_img.place(x=0,y=95,width=1480,height=590)

#Title
        titlelbl=Label(bag_img,text="ATTENDANCE MANAGEMENT SYSTEM",font=("calibri",35,"bold"),bg="black",fg="white")
        titlelbl.place(x=-5,y=0,width=1290,height=45)

#Main Frame
        main_frame=Frame(bag_img,bd=2,bg="White")
        main_frame.place(x=10,y=55,width=1255,height=490)

#Left Frame
        left_frame=LabelFrame(main_frame,bd=2,bg="White",relief=RIDGE,text="student1 Attendance Details",font=("calibri",15,"bold"))
        left_frame.place(x=10,y=10,width=600,height=455)

#Attendance Frame
        attend_frame=Frame(left_frame,bd=2,bg="White",relief=RIDGE)
        attend_frame.place(x=12,y=5,width=573,height=400)

        #attendid
        idlabel=Label(attend_frame,text="Name:",font=("calibri",15,"bold"),bg="White")
        idlabel.grid(row=0,column=0,padx=10,pady=15,sticky=W)

        idst=ttk.Entry(attend_frame,width=13,textvariable=self.var_name,font=("calibri",14,"bold"))
        idst.grid(row=0,column=1,padx=0,pady=15,sticky=W)
        #rollno
        rollabel=Label(attend_frame,text="Enrollment No:",font=("calibri",15,"bold"),bg="White")
        rollabel.grid(row=0,column=2,padx=10,pady=15,sticky=W)

        rollst=ttk.Entry(attend_frame,width=13,textvariable=self.var_enrollid,font=("calibri",14,"bold"))
        rollst.grid(row=0,column=3,padx=0,pady=15,sticky=W)
        #RollNo
        datelabel=Label(attend_frame,text="Roll No:",font=("calibri",15,"bold"),bg="White")
        datelabel.grid(row=1,column=0,padx=10,pady=15,sticky=W)

        datest=ttk.Entry(attend_frame,width=13,textvariable=self.var_rollno,font=("calibri",14,"bold"))
        datest.grid(row=1,column=1,padx=0,pady=15,sticky=W)
        #department
        deplabel=Label(attend_frame,text="Department:",font=("calibri",15,"bold"),bg="White")
        deplabel.grid(row=1,column=2,padx=10,pady=15,sticky=W)

        depst=ttk.Entry(attend_frame,width=13,textvariable=self.var_dept,font=("calibri",14,"bold"))
        depst.grid(row=1,column=3,padx=0,pady=15,sticky=W)
        #Time
        timelabel=Label(attend_frame,text="Time:",font=("calibri",15,"bold"),bg="White")
        timelabel.grid(row=2,column=0,padx=10,pady=15,sticky=W)

        timest=ttk.Entry(attend_frame,width=13,textvariable=self.var_time,font=("calibri",14,"bold"))
        timest.grid(row=2,column=1,padx=0,pady=15,sticky=W)
        #date
        datelabel=Label(attend_frame,text="Date:",font=("calibri",15,"bold"),bg="White")
        datelabel.grid(row=2,column=2,padx=10,pady=15,sticky=W)

        datest=ttk.Entry(attend_frame,width=13,textvariable=self.var_date,font=("calibri",14,"bold"))
        datest.grid(row=2,column=3,padx=0,pady=15,sticky=W)
        #attendance
        atlabel=Label(attend_frame,text="Attendance:",font=("calibri",15,"bold"),bg="White")
        atlabel.grid(row=3,column=0,padx=10,pady=15,sticky=W)

        attend_combo=ttk.Combobox(attend_frame,textvariable=self.var_status,font=("calibri",14,"bold"),state="readonly",width=11)
        attend_combo["values"]=("Your Status","Present","Absent")
        attend_combo.current(0)
        attend_combo.grid(row=3,column=1,padx=0,pady=15,sticky=W)

#Button Frame
        btn_frame=LabelFrame(attend_frame,bd=2,bg="White",relief=RIDGE)
        btn_frame.place(x=12,y=300,width=545,height=65)
        #save
        save_btn=Button(btn_frame,text="IMPORT CSV",command=self.importcsv,font=("calibri",11,"bold"),bg="black",fg="white",width=33)
        save_btn.grid(row=0,column=0)
        #update
        update_btn=Button(btn_frame,text="EXPORT CSV",command=self.exportcsv,font=("calibri",11,"bold"),bg="black",fg="white",width=33)
        update_btn.grid(row=0,column=1)
        #delete
        del_btn=Button(btn_frame,text="UPDATE CSV",command=self.update_data,font=("calibri",11,"bold"),bg="black",fg="white",width=33)
        del_btn.grid(row=1,column=0)
        #reset
        reset_btn=Button(btn_frame,text="RESET CSV",command=self.reset_data,font=("calibri",11,"bold"),bg="black",fg="white",width=33)
        reset_btn.grid(row=1,column=1)


#Right Frame
        right_frame=LabelFrame(main_frame,bd=2,bg="White",relief=RIDGE,text="student1 Attendance Details",font=("calibri",15,"bold"))
        right_frame.place(x=640,y=10,width=600,height=455)

        table_frame=Frame(right_frame,bd=2,bg="White",relief=RIDGE)
        table_frame.place(x=12,y=5,width=573,height=400)

        #scrollbar
        scroll_x=ttk.Scrollbar(table_frame,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(table_frame,orient=VERTICAL)

        self.attendancetable=ttk.Treeview(table_frame,column=("name","enrollid","roll","dept","time","date","attendance"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_x.config(command=self.attendancetable.xview)
        scroll_y.config(command=self.attendancetable.yview)

        self.attendancetable.heading("name",text="Name")
        self.attendancetable.heading("enrollid",text="Enrollment Id")
        self.attendancetable.heading("roll",text="Roll No")
        self.attendancetable.heading("dept",text="Department")
        self.attendancetable.heading("time",text="Time")
        self.attendancetable.heading("date",text="Text")
        self.attendancetable.heading("attendance",text="Attendance Status")
        self.attendancetable["show"]="headings"

        self.attendancetable.column("name",width=120)
        self.attendancetable.column("enrollid",width=100)
        self.attendancetable.column("roll",width=80)
        self.attendancetable.column("dept",width=100)
        self.attendancetable.column("time",width=100)
        self.attendancetable.column("date",width=100)
        self.attendancetable.column("attendance",width=140)

        self.attendancetable.pack(fill=BOTH,expand=1)

        self.attendancetable.bind("<ButtonRelease>",self.get_cursor)

#fetchdata
    def fetchdata(self,rows):
        self.attendancetable.delete(*self.attendancetable.get_children())
        for i in rows:
            self.attendancetable.insert("",END,values=i)

    #import csv
    def importcsv(self):
        global mydata
        fln=filedialog.askopenfilename(initialdir=os.getcwd(),title="Open CSV",filetypes=(("CSV File","*csv"),("All File","*.*")),parent=self.root)
        with open(fln) as  myfile:
            csvread=csv.reader(myfile,delimiter=",")
            for i in csvread:
                mydata.append(i)
            self.fetchdata(mydata)

    #export csv
    def exportcsv(self):
        try:
            if len(mydata)<1:
                messagebox.showerror("No Data","No Data Found To Export",parent=self.root)
                return False
            fln=filedialog.asksaveasfilename(initialdir=os.getcwd(),title="Open CSV",filetypes=(("CSV File","*csv"),("All File","*.*")),parent=self.root)
            with open(fln,mode="w",newline="") as myfile:
                exp_write=csv.writer(myfile,delimiter=",")
                for i in mydata:
                    exp_write.writerow(i)
                messagebox.showinfo("Data Export","Your Data Exported To:"+os.path.basename(fln)+"Successfully!")
        except Exception as ex:
            messagebox.showerror("Error",f"Due To:{str(ex)}",parent=self.root)

    #cursor
    def get_cursor(self,enent=""):
        cursor_row=self.attendancetable.focus()
        content=self.attendancetable.item(cursor_row)
        rows=content['values']
        self.var_name.set(rows[0])
        self.var_enrollid.set(rows[1])
        self.var_rollno.set(rows[2])
        self.var_dept.set(rows[3])
        self.var_time.set(rows[4])
        self.var_date.set(rows[5])
        self.var_status.set(rows[6])

    #reset
    def reset_data(self):
        cursor_row=self.attendancetable.focus()
        content=self.attendancetable.item(cursor_row)
        rows=content['values']
        self.var_name.set("")
        self.var_enrollid.set("")
        self.var_rollno.set("")
        self.var_dept.set("")
        self.var_time.set("")
        self.var_date.set("")
        self.var_status.set("")

#update function
    def update_data(self):
        os.startfile(r"C:\Users\nikhi\Python\FaceRecognition\Attendance.csv")


if __name__ == "__main__":
    root=Tk()
    obj=Attend(root)
    root.mainloop()