from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
import cv2
import os

class developer:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1275x910+0+0")
        self.root.title("About Developer")

#background
        bgimg=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\develop.jpg")
        bgimg=bgimg.resize((1280,920),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(bgimg)

        bag_img=Label(self.root,image=self.photoimg4)
        bag_img.place(x=-9,y=0,width=1300,height=920)

#Title
        titlelbl=Label(self.root,text="DEVELOPED BY",font=("calibri",35,"bold"),bg="White",fg="black")
        titlelbl.place(x=-5,y=100,width=1290,height=45)

#Main Frame
        main_frame=Frame(bag_img,bd=2,bg="White")
        main_frame.place(x=800,y=155,width=470,height=470)

#image  
        dvimg=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\dev2.jpg")
        dvimg=dvimg.resize((110,110),Image.ANTIALIAS)
        self.photoimgdev=ImageTk.PhotoImage(dvimg)

        dev_img=Label(main_frame,image=self.photoimgdev)
        dev_img.place(x=190,y=10,width=110,height=110)

#Developerinfo
        devlbl=Label(main_frame,text="This Is Our Final Year Project By:",font=("calibri",15,"bold"),bg="White",fg="black")
        devlbl.place(x=90,y=120,width=300,height=45)

        lbl1=Label(self.root,text="Nikhil Vishvanath Tandel",font=("calibri",20,"bold"),bg="White",fg="black")
        lbl1.place(x=870,y=320,width=320,height=45)

        lbl2=Label(self.root,text="Mayur Gaikwad",font=("calibri",20,"bold"),bg="White",fg="black")
        lbl2.place(x=855,y=370,width=350,height=45)

        lbl3=Label(self.root,text="Yash Patil",font=("calibri",20,"bold"),bg="White",fg="black")
        lbl3.place(x=850,y=420,width=350,height=45)

        lbl4=Label(self.root,text="Done Using Python",font=("calibri",25,"bold"),bg="White",fg="black")
        lbl4.place(x=860,y=540,width=350,height=50)

if __name__ == "__main__":
    root=Tk()
    obj=developer(root)
    root.mainloop()