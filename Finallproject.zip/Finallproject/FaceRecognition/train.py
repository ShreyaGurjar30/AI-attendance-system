from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import cv2
import os
import numpy as np

class Training:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1275x910+0+0")
        self.root.title("Training Your Data")

        titlelbl=Label(self.root,text="TRAIN DATA SET",font=("calibri",45,"bold"),bg="White",fg="red")
        titlelbl.place(x=-5,y=0,width=1290,height=45)

#1st
        imgtop=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\faceall.png")
        imgtop=imgtop.resize((1300,300),Image.ANTIALIAS)
        self.photoimgtop=ImageTk.PhotoImage(imgtop)

        toplabel=Label(self.root,image=self.photoimgtop)
        toplabel.place(x=-8,y=45,width=1295,height=300)
#2nd
        imgbot=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\bgstud.jpg")
        imgbot=imgbot.resize((1300,330),Image.ANTIALIAS)
        self.photoimgbot=ImageTk.PhotoImage(imgbot)

        botlabel=Label(self.root,image=self.photoimgbot)
        botlabel.place(x=-8,y=330,width=1295,height=315)

#button
        btn1=Button(self.root,text="Train Data",command=self.train_class,cursor="hand2",font=("calibri",25,"bold"),bg="black",fg="white")
        btn1.place(x=-3,y=305,width=1300,height=45)

    def train_class(self):
        data_dir=(r"D:\Degree\Face-Recognition\Finallproject\FaceRecognition\Data")
        path=[os.path.join(data_dir,file) for file in os.listdir(data_dir)]

        faces=[]
        ids=[]
        for image in path:
            img=Image.open(image).convert('L') #Grayscale
            imageNp=np.array(img,'uint8')
            id=int(os.path.split(image)[1].split('.')[1])

            faces.append(imageNp)
            ids.append(id)
            cv2.imshow("Training",imageNp)
            cv2.waitKey(1)==13

        ids=np.array(ids)

#train 
        clf=cv2.face.LBPHFaceRecognizer_create()
        clf.train(faces,ids)
        clf.write(r"D:\Degree\Face-Recognition\Finallproject\FaceRecognition\Classifier.xml")
        cv2.destroyAllWindows()
        messagebox.showinfo("Result","Training Datasets Completed!",parent=self.root)

if __name__ == "__main__":
    root=Tk()
    obj=Training(root)
    root.mainloop()