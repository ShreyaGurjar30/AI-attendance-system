from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
import mysql.connector
import cv2
import os

class helpi:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1275x910+0+0")
        self.root.title("Get Some Help")

#background
        bgimg=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\helpdesk.jpg")
        bgimg=bgimg.resize((1280,910),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(bgimg)

        bag_img=Label(self.root,image=self.photoimg4)
        bag_img.place(x=-9,y=0,width=1280,height=910)

#Title
        titlelbl=Label(self.root,text="HELP DESK",font=("calibri",35,"bold"),bg="black",fg="white")
        titlelbl.place(x=-5,y=30,width=1290,height=50)

#Developerinfo
        devlbl=Label(self.root,text="Contact:",font=("calibri",25,"bold"),bg="White",fg="black")
        devlbl.place(x=840,y=390,width=350,height=45)

        lbl1=Label(self.root,text="Nikhil : 7400345416",font=("calibri",20,"bold"),bg="White",fg="black")
        lbl1.place(x=840,y=460,width=350,height=45)

        lbl2=Label(self.root,text="Mayur : 8605337077",font=("calibri",20,"bold"),bg="White",fg="black")
        lbl2.place(x=840,y=510,width=350,height=45)

        lbl3=Label(self.root,text="Yash : 8369806803",font=("calibri",20,"bold"),bg="White",fg="black")
        lbl3.place(x=840,y=560,width=350,height=45)


if __name__ == "__main__":
    root=Tk()
    obj=helpi(root)
    root.mainloop()