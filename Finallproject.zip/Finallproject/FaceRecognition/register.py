from tkinter import*
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
from facial import Face_Recognize
import mysql.connector
import cv2
import os
from login import main

class forgott:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1275x910+0+0")
        self.root.title("Forgot Password")

#variables
        self.var_fname=StringVar()
        self.var_lname=StringVar()
        self.var_contac=StringVar()
        self.var_email=StringVar()
        self.var_secQ=StringVar()
        self.var_secA=StringVar()
        self.var_pass=StringVar()
        self.var_confpass=StringVar()

#background
        bgimg=Image.open(r"D:\Degree\Face-Recognition\Finallproject\Facialimages\register1.jpg")
        bgimg=bgimg.resize((1280,800),Image.ANTIALIAS)
        self.photoimg4=ImageTk.PhotoImage(bgimg)

        bag_img=Label(self.root,image=self.photoimg4)
        bag_img.place(x=-9,y=0,width=1290,height=800)

        titlelbl=Label(self.root,text="FORGOT PASSWORD",font=("calibri",45,"bold"),bg="white",fg="black")
        titlelbl.place(x=-5,y=25,width=1290,height=45)

        mainframe=Frame(self.root,bg="white")
        mainframe.place(x=300,y=95,width=690,height=485)

        reglbl=Label(mainframe,text="Register Here",font=("calibri",25,"bold"),bg="White",fg="black")
        reglbl.place(x=20,y=14)


        #Name
        namelabel=Label(mainframe,text="First Name",font=("calibri",16,"bold"),bg="White")
        namelabel.place(x=30,y=69)

        self.nametb=ttk.Entry(mainframe,textvariable=self.var_fname,width=27,font=("calibri",15,"bold"))
        self.nametb.place(x=32,y=102)

        #LastName
        namelaslabel=Label(mainframe,text="Last Name",font=("calibri",16,"bold"),bg="White")
        namelaslabel.place(x=380,y=69)

        self.namelastb=ttk.Entry(mainframe,textvariable=self.var_lname,width=27,font=("calibri",15,"bold"))
        self.namelastb.place(x=382,y=102)

        #Contact
        conlabel=Label(mainframe,text="Contact",font=("calibri",16,"bold"),bg="White")
        conlabel.place(x=30,y=135)

        self.contb=ttk.Entry(mainframe,textvariable=self.var_contac,width=27,font=("calibri",15,"bold"))
        self.contb.place(x=32,y=167)
        
        #Email
        emalabel=Label(mainframe,text="Email Id",font=("calibri",16,"bold"),bg="White")
        emalabel.place(x=380,y=135)

        self.ematb=ttk.Entry(mainframe,textvariable=self.var_email,width=27,font=("calibri",15,"bold"))
        self.ematb.place(x=382,y=167)

        #Security
        seclabel=Label(mainframe,text="Select Security Question",font=("calibri",16,"bold"),bg="White")
        seclabel.place(x=30,y=203)

        sec_combo=ttk.Combobox(mainframe,textvariable=self.var_secQ,font=("calibri",14,"bold"),state="readonly",width=25)
        sec_combo["values"]=("Select Question","Your Birth Date","Favourite Anime","Favourite Subject")
        sec_combo.current(0)
        sec_combo.place(x=32,y=239)

        #Ans
        anslabel=Label(mainframe,text="Security Answer",font=("calibri",16,"bold"),bg="White")
        anslabel.place(x=380,y=203)

        self.anstb=ttk.Entry(mainframe,textvariable=self.var_secA,width=27,font=("calibri",15,"bold"))
        self.anstb.place(x=382,y=239)

        #Password
        passlabel=Label(mainframe,text="Password",font=("calibri",16,"bold"),bg="White")
        passlabel.place(x=30,y=269)

        self.passtb=ttk.Entry(mainframe,show="*",textvariable=self.var_pass,width=27,font=("calibri",15,"bold"))
        self.passtb.place(x=32,y=305)

        #Confirm
        conflabel=Label(mainframe,text="Confirm Password",font=("calibri",16,"bold"),bg="White")
        conflabel.place(x=380,y=269)

        self.conftb=ttk.Entry(mainframe,show="*",textvariable=self.var_confpass,width=27,font=("calibri",15,"bold"))
        self.conftb.place(x=382,y=305)

        #checkbutton
        self.varcond=IntVar()
        chk_btn=Checkbutton(mainframe,variable=self.varcond,text="I Agree The Terms & Conditions",font=("calibri",14,"bold"),bg="white",onvalue=1,offvalue=0)
        chk_btn.place(x=30,y=350)

#loginbutton 
        log_btn=Button(mainframe,command=self.register_data,text="Register Now",font=("calibri",17,"bold"),fg="white",bg="black",width=11)
        log_btn.place(x=195,y=420,width=150,height=34)
#registerbutton 
        reg_btn=Button(mainframe,text="Login Now",font=("calibri",17,"bold"),fg="white",bg="black",width=11)
        reg_btn.place(x=345,y=420,width=150,height=34)

#register function
    def register_data(self):
        if self.var_fname.get()=="" or self.var_secQ.get()=="Select Question" or self.var_pass.get()=="":
            messagebox.showerror("Error","Please Fill Proper Data",parent=self.root)
        elif self.var_pass.get()!=self.var_confpass.get():
            messagebox.showerror("Error","Password And Confirm Password Should Be Same",parent=self.root)
        elif self.varcond.get()==0:
            messagebox.showerror("Error","Please Agree Our Terms And Conditions",parent=self.root)
        elif len(self.var_pass.get())<(8):
                messagebox.showerror("Error","Please Enter Password Greater Than 8 Characters")
        else:
            try:
                conn=mysql.connector.connect(host="localhost",user="root",password="",database="face_recognizer")
                my_cursor=conn.cursor()
                query=("select * from register where email=%s")
                value=(self.var_pass.get(),)
                my_cursor.execute(query,value)
                row=my_cursor.fetchone()
                if row!=None:
                    messagebox.showerror("Error","User Already Exist,Try Other Gmail Account",parent=self.root)
                else:
                    my_cursor.execute("insert into register values (%s,%s,%s,%s,%s,%s,%s)",(self.var_fname.get(),self.var_lname.get(),self.var_contac.get(),self.var_email.get(),self.var_secQ.get(),self.var_secA.get(),self.var_pass.get()))
                    messagebox.showinfo("Success","User Registeration Successfull",parent=self.root)
                conn.commit()
                conn.close()
            except Exception as ex:
                messagebox.showerror("Error",f"Due To:{str(ex)}",parent=self.root)


if __name__ == "__main__":
    root=Tk()
    obj=forgott(root)
    root.mainloop()